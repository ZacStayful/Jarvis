const CALENDLY_USER_UUID = '4524c498-f081-4a94-b99d-e0122bb33215';
const CALENDLY_USER_URI = `https://api.calendly.com/users/${CALENDLY_USER_UUID}`;

export default async function handler(req, res) {
  if (req.method !== 'GET' && req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const CALENDLY_API_KEY = process.env.CALENDLY_API_KEY;
  if (!CALENDLY_API_KEY) return res.status(500).json({ error: 'Calendly API key not configured' });

  const timezone = req.body?.timezone || req.query?.timezone || 'Europe/London';

  try {
    // Get event types
    const eventTypesRes = await fetch(
      `https://api.calendly.com/event_types?user=${encodeURIComponent(CALENDLY_USER_URI)}&active=true`,
      { headers: { Authorization: `Bearer ${CALENDLY_API_KEY}`, 'Content-Type': 'application/json' } }
    );
    const eventTypesData = await eventTypesRes.json();

    if (!eventTypesData.collection?.length) {
      return res.status(404).json({ error: 'No active event types found' });
    }

    const callEvent = eventTypesData.collection.find(e => e.slug === 'call') ||
      eventTypesData.collection.find(e =>
        e.name?.toLowerCase().includes('airbnb profitability') ||
        e.name?.toLowerCase().includes('action plan')
      ) ||
      eventTypesData.collection[0];

    // Query 3 x 7-day windows (Calendly max 7 days per call)
    const now = new Date();
    const allSlots = [];

    for (let i = 0; i < 3; i++) {
      const start = new Date(now);
      start.setDate(start.getDate() + (i * 7));
      const end = new Date(start);
      end.setDate(end.getDate() + 7);

      const availRes = await fetch(
        `https://api.calendly.com/event_type_available_times?event_type=${encodeURIComponent(callEvent.uri)}&start_time=${start.toISOString()}&end_time=${end.toISOString()}`,
        { headers: { Authorization: `Bearer ${CALENDLY_API_KEY}`, 'Content-Type': 'application/json' } }
      );
      const availData = await availRes.json();
      if (availData.collection?.length) {
        allSlots.push(...availData.collection);
      }
    }

    if (!allSlots.length) {
      return res.status(200).json({
        success: true,
        available_slots: [],
        voice_summary: `I don't have any slots showing in the next three weeks — the best thing is for me to send you a direct booking link so you can pick a time. Could I take your email address?`
      });
    }

    // Filter to Mon-Fri 9am-6pm BST
    const filtered = allSlots.filter(slot => {
      const d = new Date(slot.start_time);
      const hour = d.getUTCHours() + 1; // BST
      const day = d.getUTCDay();
      return day >= 1 && day <= 5 && hour >= 9 && hour <= 17;
    });

    if (!filtered.length) {
      return res.status(200).json({
        success: true,
        available_slots: [],
        voice_summary: `I don't have any slots showing right now — let me send you a direct booking link so you can pick a time that works.`
      });
    }

    // Group slots by date (YYYY-MM-DD in BST)
    const byDate = {};
    for (const slot of filtered) {
      const d = new Date(slot.start_time);
      const dateKey = d.toLocaleDateString('en-GB', { timeZone: timezone, year: 'numeric', month: '2-digit', day: '2-digit' });
      if (!byDate[dateKey]) byDate[dateKey] = [];
      byDate[dateKey].push(slot);
    }

    const dates = Object.keys(byDate).sort((a, b) => {
      const [da, ma, ya] = a.split('/');
      const [db, mb, yb] = b.split('/');
      return new Date(`${ya}-${ma}-${da}`) - new Date(`${yb}-${mb}-${db}`);
    });

    // Day 1: find one AM and one PM slot
    // Fallback: if day only has one type, offer first two available slots
    const day1Key = dates[0];
    const day1Slots = byDate[day1Key];
    const day1Date = new Date(day1Slots[0].start_time);

    let amSlot = day1Slots.find(s => {
      const h = new Date(s.start_time).getUTCHours() + 1;
      return h >= 9 && h < 12;
    }) || null;
    let pmSlot = day1Slots.find(s => {
      const h = new Date(s.start_time).getUTCHours() + 1;
      return h >= 12 && h <= 17;
    }) || null;

    // If no AM slot, use first two slots on Day 1 as the two options
    if (!amSlot) {
      amSlot = day1Slots[0] || null;
      pmSlot = day1Slots.find(s => s.start_time !== day1Slots[0]?.start_time) || null;
    }
    // If no PM slot, use first two slots on Day 1 as the two options
    if (!pmSlot) {
      amSlot = day1Slots[0] || null;
      pmSlot = day1Slots[1] || null;
    }

    // Day 2: next available date
    const day2Key = dates[1] || null;
    const day2Slots = day2Key ? byDate[day2Key] : [];
    const day2Date = day2Slots.length ? new Date(day2Slots[0].start_time) : null;

    // Format helper
    const fmt = (isoStr, includeTime = true) => {
      const d = new Date(isoStr);
      const dayName = d.toLocaleDateString('en-GB', { weekday: 'long', timeZone: timezone });
      const date = d.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', timeZone: timezone });
      const time = d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', timeZone: timezone });
      return includeTime ? `${dayName} ${date} at ${time}` : `${dayName} ${date}`;
    };

    // Build the 3 offering slots
    const offerings = [];

    if (amSlot) {
      offerings.push({
        label: 'option_1_am',
        start_time: amSlot.start_time,
        display: fmt(amSlot.start_time)
      });
    }
    if (pmSlot) {
      offerings.push({
        label: 'option_2_pm',
        start_time: pmSlot.start_time,
        display: fmt(pmSlot.start_time)
      });
    }
    if (day2Date) {
      offerings.push({
        label: 'option_3_following_day',
        start_time: day2Slots[0].start_time,
        display: fmt(day2Date.toISOString(), false), // day only — "any time"
        anytime: true,
        all_slots: day2Slots.slice(0, 8).map(s => ({
          start_time: s.start_time,
          display: fmt(s.start_time)
        }))
      });
    }

    // Build voice summary
    let voiceSummary = '';
    const opt1 = offerings.find(o => o.label === 'option_1_am');
    const opt2 = offerings.find(o => o.label === 'option_2_pm');
    const opt3 = offerings.find(o => o.label === 'option_3_following_day');

    if (opt1 && opt2 && opt3) {
      voiceSummary = `I've got ${opt1.display}, or ${opt2.display} — or if neither of those work, I can get you in anytime on ${opt3.display}. Which would suit you best?`;
    } else if (opt1 && opt2) {
      voiceSummary = `I've got ${opt1.display} or ${opt2.display}. Which works best for you?`;
    } else if (opt1 || opt2) {
      const only = opt1 || opt2;
      voiceSummary = `I've got ${only.display} available. Does that work for you?`;
    }

    return res.status(200).json({
      success: true,
      event_type: callEvent.name,
      duration_minutes: callEvent.duration,
      timezone,
      available_slots: offerings,
      voice_summary: voiceSummary
    });

  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch availability', message: err.message });
  }
}