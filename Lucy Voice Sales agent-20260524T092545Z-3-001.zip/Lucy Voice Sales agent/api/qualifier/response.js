// api/qualifier/response.js
// Receives individual pre-qualifier answers and writes them to Monday in real time.
// Called on every "Next" press — partial data is captured even if lead abandons.
//
// POST body:
//   {
//     "monday_item_id": "12345678",
//     "field": "bedrooms",          — field key (see FIELD_MAP below)
//     "value": "3",                 — the answer
//     "question_num": 3,            — current question number (1-indexed)
//     "total_questions": 8          — total questions in the form
//   }

const BOARD_ID = "5891626711";

// Maps form field keys to Monday column IDs
const FIELD_MAP = {
  address:           "text6",
  bedrooms:          "numeric_mm2qm5xw",
  property_type:     "text_mm2qhtqa",
  property_situation:"text_mm2qwqm8",
  ltl_income:        "text_mm2dsnw7",
  mortgage:          "text_mm26pf4c",
  stl_goal:          "text_mm2qwqxd",
  timeline:          "text5",          // Description column — reused
};

const PROGRESS_COL   = "text_mm2qmww2";
const COMPLETED_COL  = "date_mm2qryq5";
const RESPONSES_COL  = "long_text_mm2pse8d";

module.exports = async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const { monday_item_id, field, value, question_num, total_questions } = req.body || {};

  if (!monday_item_id || !field || value === undefined) {
    return res.status(400).json({ error: "Missing monday_item_id, field, or value" });
  }

  const columnId = FIELD_MAP[field];
  if (!columnId) {
    return res.status(400).json({ error: `Unknown field: ${field}` });
  }

  const today = new Date().toISOString().split("T")[0];
  const timeStr = new Date().toLocaleString("en-GB", {
    timeZone: "Europe/London",
    day: "2-digit", month: "short",
    hour: "2-digit", minute: "2-digit",
  });

  const isCompleted = question_num && total_questions && question_num >= total_questions;
  const progressLabel = question_num && total_questions
    ? isCompleted
      ? `✅ Completed all ${total_questions} questions — ${timeStr}`
      : `${question_num} of ${total_questions} answered — ${timeStr}`
    : `In progress — ${timeStr}`;

  // Build column values to write
  const columnValues = {
    [columnId]: field === "bedrooms"
      ? Number(value) || 0
      : String(value),
    [PROGRESS_COL]: progressLabel,
  };

  // Stamp completion date if they finished
  if (isCompleted) {
    columnValues[COMPLETED_COL] = { date: today };
  }

  try {
    // ── 1. Fetch existing Presentation Responses to append ─────────────────
    const fetchRes = await fetch("https://api.monday.com/v2", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: process.env.MONDAY_API_KEY,
        "API-Version": "2024-01",
      },
      body: JSON.stringify({
        query: `query ($id: [ID!]!) {
          items(ids: $id) {
            column_values(ids: ["${RESPONSES_COL}"]) { text }
          }
        }`,
        variables: { id: [monday_item_id] },
      }),
    });
    const fetchData = await fetchRes.json();
    const existing = fetchData?.data?.items?.[0]?.column_values?.[0]?.text || "";

    // Append this answer to the log
    const logLine = `[${timeStr}] ${field}: ${value}`;
    columnValues[RESPONSES_COL] = [logLine, existing].filter(Boolean).join("\n");

    // ── 2. Write columns ───────────────────────────────────────────────────
    await fetch("https://api.monday.com/v2", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: process.env.MONDAY_API_KEY,
        "API-Version": "2024-01",
      },
      body: JSON.stringify({
        query: `mutation ($itemId: ID!, $boardId: ID!, $values: JSON!) {
          change_multiple_column_values(item_id: $itemId, board_id: $boardId, column_values: $values) { id }
        }`,
        variables: {
          itemId: String(monday_item_id),
          boardId: BOARD_ID,
          values: JSON.stringify(columnValues),
        },
      }),
    });

    // ── 3. Post Monday update on completion only ───────────────────────────
    if (isCompleted) {
      await fetch("https://api.monday.com/v2", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: process.env.MONDAY_API_KEY,
          "API-Version": "2024-01",
        },
        body: JSON.stringify({
          query: `mutation ($itemId: ID!, $body: String!) {
            create_update(item_id: $itemId, body: $body) { id }
          }`,
          variables: {
            itemId: String(monday_item_id),
            body: `✅ Pre-Qualifier Completed — ${timeStr}\nAll ${total_questions} questions answered. Ready to build presentation.`,
          },
        }),
      });
    }

    console.log(`[qualifier] item ${monday_item_id} — ${field}: ${value} (Q${question_num}/${total_questions})`);
    return res.status(200).json({ ok: true, field, progress: progressLabel });
  } catch (err) {
    console.error("[qualifier] Error:", err.message);
    return res.status(500).json({ error: "Write failed" });
  }
};
