// api/tracking/presentation.js
// Receives tracking events fired from Stayful presentation pages.
// Updates Monday columns in real time as the lead navigates slides.
//
// POST body:
//   {
//     "monday_item_id": "12345678",
//     "event": "viewed" | "slide_viewed" | "completed",
//     "slide": 3,        — 0-indexed slide number
//     "total": 9         — total slides in this presentation
//   }
//
// Monday columns written:
//   Presentation Viewed  (date_mm2qppyp) — stamped on first "viewed" event only
//   Slide Progress       (text_mm2pfnft) — updated on every slide_viewed event
//   Presentation Responses (long_text_mm2pse8d) — running log of all events

const BOARD_ID = "5891626711";
const PRESENTATION_VIEWED_COL = "date_mm2qppyp";
const SLIDE_PROGRESS_COL = "text_mm2pfnft";
const PRESENTATION_RESPONSES_COL = "long_text_mm2pse8d";

module.exports = async function handler(req, res) {
  // Allow CORS — presentations are on a different domain
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const { monday_item_id, event, slide, total } = req.body || {};

  if (!monday_item_id || !event) {
    return res.status(400).json({ error: "Missing monday_item_id or event" });
  }

  const now = new Date();
  const today = now.toISOString().split("T")[0];
  const timeStr = now.toLocaleString("en-GB", {
    timeZone: "Europe/London",
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });

  const slideNum = typeof slide === "number" ? slide + 1 : null; // convert to 1-indexed
  const columnValues = {};
  let logLine = "";
  let updateText = null;

  if (event === "viewed") {
    // First open — stamp Presentation Viewed date and log it
    columnValues[PRESENTATION_VIEWED_COL] = { date: today };
    columnValues[SLIDE_PROGRESS_COL] = `Slide 1 / ${total || "?"} — opened ${timeStr}`;
    logLine = `👁 Presentation opened — ${timeStr}`;
    updateText = `👁 Presentation Opened — ${timeStr}\nSlide 1 of ${total || "?"}`;

  } else if (event === "slide_viewed") {
    // Slide navigation — update progress only, no update post (too noisy)
    const progressLabel =
      slideNum === total
        ? `✅ Completed — ${timeStr}`
        : `Slide ${slideNum} / ${total} — last active ${timeStr}`;
    columnValues[SLIDE_PROGRESS_COL] = progressLabel;
    logLine = `→ Slide ${slideNum} / ${total} — ${timeStr}`;

  } else if (event === "completed") {
    // Reached last slide
    columnValues[SLIDE_PROGRESS_COL] = `✅ Completed all ${total} slides — ${timeStr}`;
    logLine = `✅ Presentation completed — ${timeStr}`;
    updateText = `✅ Presentation Completed — ${timeStr}\nLead viewed all ${total} slides.`;
  }

  try {
    // ── 1. Append to Presentation Responses log ────────────────────────────
    // Fetch existing value first so we can prepend
    const fetchRes = await fetch("https://api.monday.com/v2", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: process.env.MONDAY_API_KEY,
        "API-Version": "2024-01",
      },
      body: JSON.stringify({
        query: `query ($id: [ID!]!) {
          items(ids: $id) {
            column_values(ids: ["${PRESENTATION_RESPONSES_COL}"]) { text }
          }
        }`,
        variables: { id: [monday_item_id] },
      }),
    });

    const fetchData = await fetchRes.json();
    const existing =
      fetchData?.data?.items?.[0]?.column_values?.[0]?.text || "";
    const newLog = logLine
      ? [logLine, existing].filter(Boolean).join("\n")
      : existing;

    if (logLine) {
      columnValues[PRESENTATION_RESPONSES_COL] = newLog;
    }

    // ── 2. Write all column updates ────────────────────────────────────────
    if (Object.keys(columnValues).length > 0) {
      await fetch("https://api.monday.com/v2", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: process.env.MONDAY_API_KEY,
          "API-Version": "2024-01",
        },
        body: JSON.stringify({
          query: `mutation ($itemId: ID!, $boardId: ID!, $values: JSON!) {
            change_multiple_column_values(item_id: $itemId, board_id: $boardId, column_values: $values) { id }
          }`,
          variables: {
            itemId: String(monday_item_id),
            boardId: BOARD_ID,
            values: JSON.stringify(columnValues),
          },
        }),
      });
    }

    // ── 3. Post Monday update on key events only (viewed + completed) ──────
    if (updateText) {
      await fetch("https://api.monday.com/v2", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: process.env.MONDAY_API_KEY,
          "API-Version": "2024-01",
        },
        body: JSON.stringify({
          query: `mutation ($itemId: ID!, $body: String!) {
            create_update(item_id: $itemId, body: $body) { id }
          }`,
          variables: {
            itemId: String(monday_item_id),
            body: updateText,
          },
        }),
      });
    }

    console.log(
      `[presentation-track] item ${monday_item_id} — ${event} — slide ${slideNum}/${total}`
    );
    return res.status(200).json({ ok: true, event, slide: slideNum });
  } catch (err) {
    console.error("[presentation-track] Error:", err.message);
    return res.status(500).json({ error: "Tracking write failed" });
  }
};
