// api/email/tracking.js
// Receives Resend webhook events for email opens.
// When a lead opens an email, this endpoint:
//   1. Extracts the monday_item_id from the email's tags
//   2. Checks the "Email Opened" checkbox on the Monday item
//   3. Stamps the "Email Opened At" date column
//   4. Posts an update note on the item so Lucy sees it in get_lead_data
//
// Setup required:
//   - In Resend dashboard: Webhooks → Add endpoint → https://stayful-voice-api.vercel.app/api/email/tracking
//   - Select event: email.opened
//   - Copy the webhook signing secret and add as RESEND_WEBHOOK_SECRET env var
//
// Required environment variables:
//   MONDAY_API_KEY          — Monday.com API token
//   RESEND_WEBHOOK_SECRET   — Signing secret from Resend webhook settings

const BOARD_ID = "5891626711";
const EMAIL_OPENED_COLUMN = "boolean_mm20x8nz";
const EMAIL_OPENED_AT_COLUMN = "date_mm208xzd";

module.exports = async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const event = req.body;

  if (event?.type !== "email.opened") {
    return res.status(200).json({ skipped: true, event: event?.type });
  }

  const emailData = event.data;
  if (!emailData) {
    return res.status(400).json({ error: "No email data in webhook payload" });
  }

  let mondayItemId = null;

  if (emailData.tags) {
    if (Array.isArray(emailData.tags)) {
      const tag = emailData.tags.find((t) => t.name === "monday_item_id");
      mondayItemId = tag?.value || null;
    } else if (typeof emailData.tags === "object") {
      mondayItemId = emailData.tags.monday_item_id || null;
    }
  }

  if (!mondayItemId) {
    console.warn("No monday_item_id in email tags. Email ID:", emailData.email_id);
    return res.status(200).json({ skipped: true, reason: "No monday_item_id tag" });
  }

  const openedAt = emailData.created_at
    ? new Date(emailData.created_at)
    : new Date();

  const openedDate = openedAt.toISOString().split("T")[0];
  const openedFormatted = openedAt.toLocaleString("en-GB", {
    timeZone: "Europe/London",
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  try {
    const columnMutation = `
      mutation UpdateEmailOpened($itemId: ID!, $boardId: ID!, $columnValues: JSON!) {
        change_multiple_column_values(
          item_id: $itemId,
          board_id: $boardId,
          column_values: $columnValues
        ) {
          id
        }
      }
    `;

    await fetch("https://api.monday.com/v2", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: process.env.MONDAY_API_KEY,
        "API-Version": "2024-01",
      },
      body: JSON.stringify({
        query: columnMutation,
        variables: {
          itemId: String(mondayItemId),
          boardId: BOARD_ID,
          columnValues: JSON.stringify({
            [EMAIL_OPENED_COLUMN]: true,
            [EMAIL_OPENED_AT_COLUMN]: { date: openedDate },
          }),
        },
      }),
    });

    const updateMutation = `
      mutation CreateUpdate($itemId: ID!, $body: String!) {
        create_update(item_id: $itemId, body: $body) {
          id
        }
      }
    `;

    await fetch("https://api.monday.com/v2", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: process.env.MONDAY_API_KEY,
        "API-Version": "2024-01",
      },
      body: JSON.stringify({
        query: updateMutation,
        variables: {
          itemId: String(mondayItemId),
          body: `📬 Email Opened — ${openedFormatted}\nThe lead opened the email sent by Lucy. This is a strong intent signal — prioritise follow-up call.`,
        },
      }),
    });

    console.log(`Email opened by lead on Monday item ${mondayItemId} at ${openedFormatted}`);

    return res.status(200).json({
      success: true,
      monday_item_id: mondayItemId,
      opened_at: openedFormatted,
    });
  } catch (err) {
    console.error("Monday update failed:", err.message);
    return res.status(500).json({ error: "Failed to update Monday" });
  }
};