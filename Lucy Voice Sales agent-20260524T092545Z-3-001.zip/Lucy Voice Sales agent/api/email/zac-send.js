// api/email/zac-send.js
// Sends a tracked email from Zac directly to a lead.
// Completely separate from Lucy's email system.
//
// POST body:
//   {
//     "monday_item_id": "12345678",
//     "subject": "Following up on your Stayful enquiry",
//     "body": "Hi Tom, ..."
//   }
//
// Required environment variables:
//   MONDAY_API_KEY   — Monday.com API token
//   RESEND_API_KEY   — Resend API key
//   ZAC_FROM_EMAIL   — e.g. zac@stayful.co.uk (add this in Vercel env vars)

const BOARD_ID = "5891626711";
const EMAIL_COLUMN_ID = "text_mkygb5xx";
const EMAIL_SENT_COLUMN = "date_mm2q9b8g";

module.exports = async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { monday_item_id, subject, body } = req.body || {};

  if (!monday_item_id || !subject || !body) {
    return res.status(400).json({
      error: "Missing required fields: monday_item_id, subject, body",
    });
  }

  // ── 1. Fetch lead email and name from Monday ───────────────────────────────
  let lead;
  try {
    const mondayRes = await fetch("https://api.monday.com/v2", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: process.env.MONDAY_API_KEY,
        "API-Version": "2024-01",
      },
      body: JSON.stringify({
        query: `query ($id: [ID!]!) {
          items(ids: $id) {
            id
            name
            column_values {
              id
              text
            }
          }
        }`,
        variables: { id: [monday_item_id] },
      }),
    });

    const mondayData = await mondayRes.json();
    if (mondayData.errors || !mondayData.data?.items?.length) {
      return res.status(404).json({ error: "Lead not found in Monday" });
    }

    const item = mondayData.data.items[0];
    const cols = {};
    for (const col of item.column_values) cols[col.id] = col.text;

    lead = {
      id: item.id,
      name: item.name,
      email: cols[EMAIL_COLUMN_ID] || null,
    };
  } catch (err) {
    console.error("[zac-send] Monday fetch error:", err.message);
    return res.status(500).json({ error: "Failed to fetch lead from Monday" });
  }

  if (!lead.email) {
    return res.status(400).json({
      error: "No email address on file for this lead",
      lead_name: lead.name,
    });
  }

  // ── 2. Send via Resend ─────────────────────────────────────────────────────
  const fromAddress = process.env.ZAC_FROM_EMAIL
    ? `Zac at Stayful <${process.env.ZAC_FROM_EMAIL}>`
    : "Zac at Stayful <zac@stayful.co.uk>";

  let emailId;
  try {
    const emailRes = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: fromAddress,
        to: [lead.email],
        subject,
        text: body,
        html: `
          <div style="font-family:Arial,sans-serif;max-width:600px;color:#1a1a1a;line-height:1.6;">
            ${body
              .split("\n")
              .filter(Boolean)
              .map((line) => `<p style="margin:0 0 12px 0;">${line}</p>`)
              .join("")}
          </div>
        `,
        tags: [
          { name: "monday_item_id", value: String(lead.id) },
          { name: "trigger", value: "zac_manual" },
        ],
      }),
    });

    const emailData = await emailRes.json();
    if (!emailRes.ok) {
      console.error("[zac-send] Resend error:", JSON.stringify(emailData));
      return res.status(emailRes.status).json({
        error: "Email send failed",
        detail: emailData,
      });
    }

    emailId = emailData.id;
    console.log(`[zac-send] Sent to ${lead.email} — Resend ID: ${emailId}`);
  } catch (err) {
    console.error("[zac-send] Send error:", err.message);
    return res.status(500).json({ error: "Failed to send email" });
  }

  // ── 3. Log update on Monday item ──────────────────────────────────────────
  const sentAt = new Date().toLocaleString("en-GB", {
    timeZone: "Europe/London",
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  const updateText = `📧 Email from Zac — ${sentAt}\nTo: ${lead.email}\nSubject: ${subject}\n\n---\n\n${body}`;

  try {
    // Post update
    await fetch("https://api.monday.com/v2", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: process.env.MONDAY_API_KEY,
        "API-Version": "2024-01",
      },
      body: JSON.stringify({
        query: `mutation ($itemId: ID!, $body: String!) {
          create_update(item_id: $itemId, body: $body) { id }
        }`,
        variables: { itemId: String(monday_item_id), body: updateText },
      }),
    });

    // Stamp Email Sent date column
    const today = new Date().toISOString().split("T")[0];
    await fetch("https://api.monday.com/v2", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: process.env.MONDAY_API_KEY,
        "API-Version": "2024-01",
      },
      body: JSON.stringify({
        query: `mutation ($itemId: ID!, $boardId: ID!, $values: JSON!) {
          change_multiple_column_values(item_id: $itemId, board_id: $boardId, column_values: $values) { id }
        }`,
        variables: {
          itemId: String(monday_item_id),
          boardId: BOARD_ID,
          values: JSON.stringify({
            [EMAIL_SENT_COLUMN]: { date: today },
          }),
        },
      }),
    });
  } catch (err) {
    console.error("[zac-send] Monday write error:", err.message);
    // Don't fail — email already sent
  }

  return res.status(200).json({
    success: true,
    email_id: emailId,
    sent_to: lead.email,
    lead_name: lead.name,
  });
};
