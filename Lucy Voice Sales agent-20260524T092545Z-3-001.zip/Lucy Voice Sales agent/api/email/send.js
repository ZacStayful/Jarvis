// api/email/send.js
// Sends a follow-up email to a lead and logs it as a Monday update.
// Now includes: open tracking enabled + monday_item_id tag so the
// tracking webhook can write back to the correct Monday item when opened.
//
// POST body:
//   {
//     "monday_item_id": "12345678",
//     "subject": "Following up on your Stayful enquiry",
//     "body": "Hi Tom, ...",
//     "trigger": "end_of_call"   — end_of_call | mid_call_request | follow_up_sequence
//   }
//
// Required environment variables:
//   MONDAY_API_KEY      — Monday.com API token
//   RESEND_API_KEY      — Resend API key (resend.com)
//   STAYFUL_FROM_EMAIL  — e.g. Lucy at Stayful <lucy@stayful.co.uk>

const BOARD_ID = "5891626711";
const EMAIL_COLUMN_ID = "text_mkygb5xx";
const LAST_EMAIL_DATE_COLUMN = "date_mm1vpqam";

module.exports = async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { monday_item_id, subject, body, trigger } = req.body || {};

  if (!monday_item_id || !subject || !body) {
    return res.status(400).json({ error: "Missing required fields: monday_item_id, subject, body" });
  }

  // ── 1. Fetch lead email and name from Monday ───────────────────────────────
  let lead;
  try {
    const query = `
      query GetLead($itemId: [ID!]!) {
        items(ids: $itemId) {
          id
          name
          column_values {
            id
            text
          }
        }
      }
    `;

    const mondayRes = await fetch("https://api.monday.com/v2", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: process.env.MONDAY_API_KEY,
        "API-Version": "2024-01",
      },
      body: JSON.stringify({ query, variables: { itemId: [monday_item_id] } }),
    });

    const mondayData = await mondayRes.json();
    if (mondayData.errors || !mondayData.data?.items?.length) {
      return res.status(404).json({ error: "Lead not found in Monday" });
    }

    const item = mondayData.data.items[0];
    const cols = {};
    for (const col of item.column_values) {
      cols[col.id] = col.text;
    }

    lead = {
      name: item.name,
      email: cols[EMAIL_COLUMN_ID] || null,
      monday_item_id: item.id,
    };
  } catch (err) {
    console.error("Monday fetch failed:", err.message);
    return res.status(500).json({ error: "Failed to fetch lead from Monday" });
  }

  if (!lead.email) {
    return res.status(400).json({
      error: "No email address found for this lead in Monday",
      lead_name: lead.name,
    });
  }

  // ── 2. Send email via Resend ───────────────────────────────────────────────
  // Tags embed the monday_item_id so the tracking webhook can write
  // the "Email Opened" status back to the correct Monday item automatically.
  let emailId = null;
  try {
    const emailRes = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: process.env.STAYFUL_FROM_EMAIL || "Lucy at Stayful <lucy@stayful.co.uk>",
        to: [lead.email],
        subject: subject,
        text: body,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; color: #1a1a1a; line-height: 1.6;">
            ${body.split("\n").filter(Boolean).map(line => `<p style="margin: 0 0 12px 0;">${line}</p>`).join("")}
          </div>
        `,
        // Tags allow the tracking webhook to identify which Monday item to update
        tags: [
          { name: "monday_item_id", value: String(lead.monday_item_id) },
          { name: "trigger", value: trigger || "unknown" },
        ],
      }),
    });

    const emailData = await emailRes.json();

    if (!emailRes.ok) {
      console.error("Resend error:", JSON.stringify(emailData));
      return res.status(emailRes.status).json({
        error: "Email sending failed",
        detail: emailData,
      });
    }

    emailId = emailData.id;
    console.log(`Email sent to ${lead.email} — Resend ID: ${emailId}`);
  } catch (err) {
    console.error("Email send failed:", err.message);
    return res.status(500).json({ error: "Failed to send email" });
  }

  // ── 3. Log the email as a Monday update ───────────────────────────────────
  const sentAt = new Date().toLocaleString("en-GB", {
    timeZone: "Europe/London",
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  const triggerLabel = {
    end_of_call: "Post-call follow-up",
    mid_call_request: "Sent during call (lead requested)",
    follow_up_sequence: "24hr follow-up sequence",
  }[trigger] || "Email";

  const updateBody = `📧 Email Sent — ${sentAt}
Type: ${triggerLabel}
To: ${lead.email}
Subject: ${subject}

---

${body}`;

  try {
    const updateMutation = `
      mutation CreateUpdate($itemId: ID!, $body: String!) {
        create_update(item_id: $itemId, body: $body) { id }
      }
    `;

    await fetch("https://api.monday.com/v2", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: process.env.MONDAY_API_KEY,
        "API-Version": "2024-01",
      },
      body: JSON.stringify({
        query: updateMutation,
        variables: { itemId: String(monday_item_id), body: updateBody },
      }),
    });

    // ── 4. Update Last Email date column ──────────────────────────────────────
    const today = new Date().toISOString().split("T")[0];
    const columnMutation = `
      mutation UpdateLastEmail($itemId: ID!, $boardId: ID!, $columnValues: JSON!) {
        change_multiple_column_values(item_id: $itemId, board_id: $boardId, column_values: $columnValues) { id }
      }
    `;

    await fetch("https://api.monday.com/v2", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: process.env.MONDAY_API_KEY,
        "API-Version": "2024-01",
      },
      body: JSON.stringify({
        query: columnMutation,
        variables: {
          itemId: String(monday_item_id),
          boardId: BOARD_ID,
          columnValues: JSON.stringify({
            [LAST_EMAIL_DATE_COLUMN]: { date: today },
          }),
        },
      }),
    });
  } catch (err) {
    console.error("Monday logging failed:", err.message);
    // Don't fail the whole request — email was sent successfully
  }

  return res.status(200).json({
    success: true,
    email_id: emailId,
    sent_to: lead.email,
    lead_name: lead.name,
    subject: subject,
  });
};