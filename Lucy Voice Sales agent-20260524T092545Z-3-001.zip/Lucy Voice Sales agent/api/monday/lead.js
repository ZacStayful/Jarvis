// api/monday/lead.js
// Fetches full lead context for Lucy at the start of every call.
// Includes: previous communications, email open status, property details.
//
// GET or POST with ?item_id=12345678 or { "item_id": "12345678" }

const BOARD_ID = "5891626711";

module.exports = async function handler(req, res) {
  const item_id = req.query?.item_id || req.body?.item_id;

  if (!item_id) {
    return res.status(400).json({ error: "Missing item_id parameter" });
  }

  try {
    const query = `
      query GetLeadWithHistory($itemId: [ID!]!) {
        items(ids: $itemId) {
          id
          name
          group { id title }
          board { id name }
          column_values { id text value }
          updates(limit: 5) {
            id
            body
            created_at
            creator { name }
          }
        }
      }
    `;

    const mondayRes = await fetch("https://api.monday.com/v2", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: process.env.MONDAY_API_KEY,
        "API-Version": "2024-01",
      },
      body: JSON.stringify({ query, variables: { itemId: [item_id] } }),
    });

    const data = await mondayRes.json();

    if (data.errors || !data.data?.items?.length) {
      return res.status(404).json({ error: "Lead not found" });
    }

    const item = data.data.items[0];
    const cols = {};
    for (const col of item.column_values) {
      cols[col.id] = col.text;
    }

    // ── Parse previous communications ──────────────────────────────────────
    const previousCommunications = (item.updates || []).map((update) => {
      const body = update.body || "";
      const createdAt = new Date(update.created_at).toLocaleString("en-GB", {
        timeZone: "Europe/London",
        day: "2-digit", month: "short", year: "numeric",
        hour: "2-digit", minute: "2-digit",
      });

      let type = "note";
      if (body.startsWith("📞")) type = "call";
      if (body.startsWith("📧")) type = "email";
      if (body.startsWith("💬")) type = "whatsapp";
      if (body.startsWith("📬")) type = "email_opened";

      const summaryRaw = body.split("---")[0].trim();
      const summary = summaryRaw.length > 400 ? summaryRaw.substring(0, 400) + "..." : summaryRaw;

      let emailContent = null;
      if (type === "email") {
        const parts = body.split("---");
        if (parts.length > 1) emailContent = parts[1]?.trim() || null;
      }

      return {
        type,
        date: createdAt,
        summary,
        email_content: emailContent || undefined,
      };
    });

    // ── Email open status ──────────────────────────────────────────────────
    const emailOpened = cols["boolean_mm20x8nz"] === "true" || cols["boolean_mm20x8nz"] === "v";
    const emailOpenedAt = cols["date_mm208xzd"] || null;

    // ── Communication context string for Lucy ──────────────────────────────
    let communicationContext = "No previous contact recorded.";
    if (previousCommunications.length > 0) {
      const lines = previousCommunications.map((c, i) => {
        if (c.type === "email_opened") return `${i + 1}. ${c.summary}`;
        if (c.type === "call") return `${i + 1}. Call on ${c.date}: ${c.summary}`;
        if (c.type === "email") return `${i + 1}. Email sent on ${c.date}: ${c.summary}${c.email_content ? `\n   Content: "${c.email_content.substring(0, 200)}..."` : ""}`;
        return `${i + 1}. ${c.type} on ${c.date}: ${c.summary}`;
      });
      communicationContext = lines.join("\n");
    }

    const lead = {
      item_id: item.id,
      name: item.name,
      group: item.group?.title || null,
      board: item.board?.name || null,

      address: cols["text6"] || null,
      email: cols["text_mkygb5xx"] || null,
      phone: cols["phone_mm1hp0a8"] || null,

      lead_profile: cols["dropdown_mm0wabga"] || null,
      status: cols["status5"] || null,
      estimated_airbnb_rent: cols["numbers_mkn25e0y"] || null,
      description: cols["text5"] || null,
      special_offer: cols["text_mm1v16ns"] || null,
      stayful_analyser_info: cols["text_mm1ymftc"] || null,
      lost_reason: cols["color_mm1v2s3m"] || null,

      last_phoned_no_answer: cols["date_mkwts3mz"] || null,
      last_phoned_answered: cols["date_mm1jj0vr"] || null,
      last_email: cols["date_mm1vpqam"] || null,
      last_text: cols["date_mm1nmb17"] || null,
      due_to_call: cols["date6"] || null,
      date_added: cols["date"] || null,

      email_opened: emailOpened,
      email_opened_at: emailOpenedAt,

      previous_communications: previousCommunications,
      last_communication: previousCommunications.length > 0 ? previousCommunications[0] : null,
      communication_context: communicationContext,
    };

    return res.status(200).json({ success: true, lead });
  } catch (err) {
    console.error("Lead fetch failed:", err.message);
    return res.status(500).json({ error: "Failed to fetch lead data" });
  }
};