// api/monday/update_status.js
// Updates a lead's status and due-to-call date in Monday.com
// Called by Lucy at the end of purchase lead calls

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { item_id, status_index, days_until_due } = req.body;

  if (!item_id || status_index === undefined) {
    return res.status(400).json({ error: 'Missing required fields: item_id and status_index' });
  }

  const MONDAY_API_KEY = process.env.MONDAY_API_KEY;
  const BOARD_ID = '5891626711';

  // Calculate due date
  const dueDate = new Date();
  dueDate.setDate(dueDate.getDate() + (days_until_due || 0));
  const dueDateStr = dueDate.toISOString().split('T')[0]; // YYYY-MM-DD

  const headers = {
    'Content-Type': 'application/json',
    'Authorization': MONDAY_API_KEY,
  };

  try {
    // Update status column
    const statusRes = await fetch('https://api.monday.com/v2', {
      method: 'POST',
      headers,
      body: JSON.stringify({
        query: `mutation { change_column_value(board_id: ${BOARD_ID}, item_id: ${item_id}, column_id: "status5", value: "{\\"index\\": ${status_index}}") { id } }`
      }),
    });

    const statusData = await statusRes.json();
    if (statusData.errors) {
      return res.status(500).json({ error: 'Status update failed', details: statusData.errors });
    }

    // Update due to call date
    const dateRes = await fetch('https://api.monday.com/v2', {
      method: 'POST',
      headers,
      body: JSON.stringify({
        query: `mutation { change_column_value(board_id: ${BOARD_ID}, item_id: ${item_id}, column_id: "date_mkwts3mz", value: "{\\"date\\": \\"${dueDateStr}\\"}" ) { id } }`
      }),
    });

    const dateData = await dateRes.json();
    if (dateData.errors) {
      return res.status(500).json({ error: 'Due date update failed', details: dateData.errors });
    }

    return res.status(200).json({
      success: true,
      item_id,
      status_index,
      due_date_set: dueDateStr,
    });

  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
}