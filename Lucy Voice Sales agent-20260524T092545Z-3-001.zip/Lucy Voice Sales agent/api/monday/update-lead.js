// UK Bank Holidays 2025-2027 (England & Wales)
const UK_BANK_HOLIDAYS = [
  '2025-01-01','2025-04-18','2025-04-21','2025-05-05','2025-05-26',
  '2025-08-25','2025-12-25','2025-12-26',
  '2026-01-01','2026-04-03','2026-04-06','2026-05-04','2026-05-25',
  '2026-08-31','2026-12-25','2026-12-28',
  '2027-01-01','2027-03-26','2027-03-29','2027-05-03','2027-05-31',
  '2027-08-30','2027-12-27','2027-12-28'
];

const LOST_REASON_LABELS = {
  'long let':        'Decided to long let property',
  'long_let':        'Decided to long let property',
  'decided to sell': 'Decided to sell',
  'selling':         'Decided to sell',
  'sell':            'Decided to sell',
  'setup cost':      'Setup costs too high',
  'setup costs':     'Setup costs too high',
  'too expensive':   'Setup costs too high',
  'local company':   'Want local company',
  'local':           'Want local company',
  'another company': 'Gone with another company',
  'competitor':      'Gone with another company',
  'gone elsewhere':  'Gone with another company',
  'income':          'Income prediction too low',
  'low income':      'Income prediction too low',
  'not enough':      'Income prediction too low',
  'none':            'None'
};

function resolveLostReason(reason) {
  if (!reason) return 'None';
  const lower = reason.toLowerCase();
  for (const [key, label] of Object.entries(LOST_REASON_LABELS)) {
    if (lower.includes(key)) return label;
  }
  return 'None';
}

function isWorkingDay(dateStr) {
  const d = new Date(dateStr);
  const day = d.getUTCDay();
  if (day === 0 || day === 6) return false;
  if (UK_BANK_HOLIDAYS.includes(dateStr)) return false;
  return true;
}

function nextWorkingDay(fromDate) {
  const d = new Date(fromDate);
  d.setDate(d.getDate() + 1);
  let dateStr = d.toISOString().split('T')[0];
  let attempts = 0;
  while (!isWorkingDay(dateStr) && attempts < 14) {
    d.setDate(d.getDate() + 1);
    dateStr = d.toISOString().split('T')[0];
    attempts++;
  }
  return dateStr;
}

function parseCallbackDate(phrase) {
  const now = new Date();
  const lower = (phrase || '').toLowerCase().trim();

  const months = ['january','february','march','april','may','june','july','august','september','october','november','december'];
  for (let i = 0; i < months.length; i++) {
    if (lower.includes(months[i])) {
      const year = now.getMonth() >= i ? now.getFullYear() + 1 : now.getFullYear();
      const dateStr = `${year}-${String(i + 1).padStart(2, '0')}-01`;
      return isWorkingDay(dateStr) ? dateStr : nextWorkingDay(dateStr);
    }
  }

  const d = new Date(now);
  if (lower.includes('240 days') || lower.includes('240days'))               d.setDate(d.getDate() + 240);
  else if (lower.includes('200 days') || lower.includes('200days'))          d.setDate(d.getDate() + 200);
  else if (lower.includes('few days') || lower.includes('couple of days'))   d.setDate(d.getDate() + 3);
  else if (lower.includes('next week') || lower.includes('week or so'))     d.setDate(d.getDate() + 7);
  else if (lower.includes('couple of weeks') || lower.includes('two weeks') || lower.includes('2 weeks')) d.setDate(d.getDate() + 14);
  else if (lower.includes('few weeks') || lower.includes('three weeks') || lower.includes('3 weeks'))     d.setDate(d.getDate() + 21);
  else if (lower.includes('month') && (lower.includes('couple') || lower.includes('two') || lower.includes('2'))) d.setMonth(d.getMonth() + 2);
  else if (lower.includes('few months') || lower.includes('three months') || lower.includes('3 months'))  d.setMonth(d.getMonth() + 3);
  else if (lower.includes('6 months') || lower.includes('six months') || lower.includes('half a year'))   d.setMonth(d.getMonth() + 6);
  else if (lower.includes('month') || lower.includes('4 weeks') || lower.includes('four weeks'))          d.setMonth(d.getMonth() + 1);
  else d.setMonth(d.getMonth() + 1);

  const dateStr = d.toISOString().split('T')[0];
  return isWorkingDay(dateStr) ? dateStr : nextWorkingDay(dateStr);
}

function addDays(days) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().split('T')[0];
}

async function postItemUpdate(itemId, body, apiKey) {
  const mutation = `
    mutation {
      create_update(
        item_id: ${itemId},
        body: ${JSON.stringify(body)}
      ) { id }
    }
  `;
  return fetch('https://api.monday.com/v2', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': apiKey,
      'API-Version': '2024-01'
    },
    body: JSON.stringify({ query: mutation })
  });
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const MONDAY_API_KEY = process.env.MONDAY_API_KEY;
  if (!MONDAY_API_KEY) return res.status(500).json({ error: 'Monday API key not configured' });

  const {
    item_id,
    action,               // 'set_future' | 'set_abandoned' | 'set_meeting_booked' | 'set_no_answer'
    callback_phrase,
    lost_reason,
    call_summary,
    keep_in_touch,
    primary_address,      // new primary address if different from Monday (string)
    additional_properties // array of { address, notes } for other properties mentioned
  } = req.body;

  if (!item_id) return res.status(400).json({ error: 'Missing item_id' });
  if (!action) return res.status(400).json({ error: 'Missing action' });

  const today = new Date().toISOString().split('T')[0];

  try {
    let columnValues = {};
    let callbackDate = null;
    let responseMessage = '';

    if (action === 'set_future') {
      callbackDate = callback_phrase ? parseCallbackDate(callback_phrase) : addDays(30);
      columnValues = {
        status5: { label: 'In the future' },
        date_mkwts3mz: { date: callbackDate },
        date_mm1vpqam: { date: today }
      };
      responseMessage = `Status set to In the future. Callback scheduled for ${callbackDate}.`;

    } else if (action === 'set_abandoned') {
      callbackDate = addDays(200);
      const resolvedLostReason = resolveLostReason(lost_reason);
      columnValues = {
        status5: { label: 'Abandoned' },
        date_mkwts3mz: { date: callbackDate },
        date_mm1vpqam: { date: today },
        color_mm1v2s3m: { label: resolvedLostReason }
      };
      responseMessage = `Status set to Abandoned. Lost reason: ${resolvedLostReason}. Due to call set to ${callbackDate}.`;

    } else if (action === 'set_no_answer') {
      columnValues = {
        date_mm0fv708: { date: today },
        date6: { date: today },
        date_mm1jj0vr: { date: today }
      };
      responseMessage = 'No answer columns updated.';

    } else if (action === 'set_meeting_booked') {
      columnValues = {
        status5: { label: 'Web meeting booked' },
        date_mm1vpqam: { date: today }
      };
      responseMessage = 'Status set to Web meeting booked.';

    } else if (action === 'set_no_show_followup') {
      // Count previous no-show followup attempts from item updates
      const attempt_number = req.body.attempt_number || 1;

      if (attempt_number >= 4) {
        // 4th attempt exhausted — set to Abandoned
        callbackDate = addDays(200);
        columnValues = {
          status5: { label: 'Abandoned' },
          date_mkwts3mz: { date: callbackDate },
          date_mm1vpqam: { date: today },
          color_mm1v2s3m: { label: 'None' }
        };
        responseMessage = `No-show followup attempt ${attempt_number} — max attempts reached. Status set to Abandoned. Due to call: ${callbackDate}.`;
      } else {
        // Still retrying — log no answer and set next due to call
        // Retry schedule: next day, +2, +3, then every 3 days
        const retryDays = [1, 2, 3, 3];
        const daysUntilNext = retryDays[attempt_number - 1] || 3;
        callbackDate = addDays(daysUntilNext);
        columnValues = {
          date_mm0fv708: { date: today },
          date_mkwts3mz: { date: callbackDate }
        };
        responseMessage = `No-show followup attempt ${attempt_number}. Next call: ${callbackDate}.`;
      }
    }

    // If primary address has changed, update the Address column
    if (primary_address) {
      columnValues['text6'] = primary_address;
      responseMessage += ` Address updated to: ${primary_address}.`;
    }

    // Update column values in Monday
    const mutation = `
      mutation {
        change_multiple_column_values(
          board_id: 5891626711,
          item_id: ${item_id},
          column_values: ${JSON.stringify(JSON.stringify(columnValues))}
        ) { id }
      }
    `;

    const mutRes = await fetch('https://api.monday.com/v2', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': MONDAY_API_KEY,
        'API-Version': '2024-01'
      },
      body: JSON.stringify({ query: mutation })
    });

    const mutData = await mutRes.json();
    if (mutData.errors) {
      return res.status(500).json({ error: 'Monday column update failed', details: mutData.errors });
    }

    // For no_show_followup, tag update with attempt number so Zapier/Lucy can count them
    if (action === 'set_no_show_followup' && req.body.attempt_number) {
      const attemptTag = `**🔁 No-Show Followup Attempt ${req.body.attempt_number} — ${callDate || today}**`;
      const attemptBody = call_summary
        ? `${attemptTag}\n\n${call_summary}`
        : `${attemptTag}\n\nCall attempted — no answer.`;

      await postItemUpdate(item_id, attemptBody, MONDAY_API_KEY);
    }

    // Post call summary as item update
    if (call_summary && action !== 'set_no_show_followup') {
      const keepInTouchNote = keep_in_touch === true
        ? '\n✅ Lead agreed to keep in touch.'
        : keep_in_touch === false
          ? '\n❌ Lead did not want to keep in touch.'
          : '';

      const addressNote = primary_address
        ? `\n📍 Primary address updated to: ${primary_address}`
        : '';

      const summaryBody = `**Call Summary — ${new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}**\n\n${call_summary}${keepInTouchNote}${addressNote}${callbackDate ? `\n\n📅 Next contact: ${callbackDate}` : ''}`;

      await postItemUpdate(item_id, summaryBody, MONDAY_API_KEY);
    }

    // Post additional properties as a separate update
    if (additional_properties && additional_properties.length > 0) {
      const propLines = additional_properties.map((p, i) => {
        const notes = p.notes ? ` — ${p.notes}` : '';
        return `${i + 1}. ${p.address}${notes}`;
      }).join('\n');

      const propertyBody = `**Additional Properties Mentioned — ${new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}**\n\nThe lead mentioned the following additional properties during the call:\n\n${propLines}\n\nThese should be reviewed on the next call. Primary property focus: ${primary_address || 'as per Address column'}.`;

      await postItemUpdate(item_id, propertyBody, MONDAY_API_KEY);
    }

    return res.status(200).json({
      success: true,
      action,
      callback_date: callbackDate,
      callback_date_display: callbackDate
        ? new Date(callbackDate).toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })
        : null,
      primary_address_updated: !!primary_address,
      additional_properties_logged: additional_properties?.length || 0,
      lost_reason: action === 'set_abandoned' ? resolveLostReason(lost_reason) : null,
      message: responseMessage
    });

  } catch (err) {
    return res.status(500).json({ error: 'Failed to update lead', message: err.message });
  }
}