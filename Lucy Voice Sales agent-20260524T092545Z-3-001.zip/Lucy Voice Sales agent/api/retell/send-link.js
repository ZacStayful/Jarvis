// api/retell/send-link.js
// Called by Lucy mid-call when a lead needs to check their calendar.
// Sends the Calendly booking link via email and appends a note to the Monday call summary.

const MONDAY_API_KEY = process.env.MONDAY_API_KEY;
const MONDAY_API_URL = 'https://api.monday.com/v2';
const RESEND_API_KEY = process.env.RESEND_API_KEY;
const CALL_SUMMARY_COLUMN = 'text_mm1v16ns';
const BOARD_ID = '5891626711';

async function getMondaySummary(itemId) {
  const query = `
    query {
      items(ids: [${itemId}]) {
        column_values(ids: ["${CALL_SUMMARY_COLUMN}"]) {
          text
        }
      }
    }
  `;

  const res = await fetch(MONDAY_API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: MONDAY_API_KEY,
    },
    body: JSON.stringify({ query }),
  });

  const data = await res.json();
  return data?.data?.items?.[0]?.column_values?.[0]?.text || '';
}

async function appendMondaySummary(itemId, newNote) {
  const existing = await getMondaySummary(itemId);
  const updated = existing
    ? `${existing}\n\n${newNote}`
    : newNote;

  const mutation = `
    mutation {
      change_simple_column_value(
        board_id: ${BOARD_ID},
        item_id: ${itemId},
        column_id: "${CALL_SUMMARY_COLUMN}",
        value: ${JSON.stringify(updated)}
      ) {
        id
      }
    }
  `;

  await fetch(MONDAY_API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: MONDAY_API_KEY,
    },
    body: JSON.stringify({ query: mutation }),
  });
}

async function sendCalendlyEmail(leadName, email) {
  const firstName = leadName?.split(' ')[0] || 'there';

  await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${RESEND_API_KEY}`,
    },
    body: JSON.stringify({
      from: 'Lucy at Stayful <lucy@stayful.co.uk>',
      to: email,
      subject: 'Your call with Zac — booking link',
      html: `
        <p>Hi ${firstName},</p>

        <p>Great speaking with you. Here's the link to book your call with Zac at a time that works for you:</p>

        <p><a href="https://calendly.com/zac-stayful/call" style="font-weight:bold;">Book your slot here</a></p>

        <p>The call takes around 30 minutes and Zac will walk you through exactly what your property could earn, based on comparable properties in your area.</p>

        <p>Speak soon,<br>Lucy<br>Stayful</p>
      `,
    }),
  });
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { lead_name, email, monday_item_id } = req.body || {};

  if (!email || !monday_item_id) {
    return res.status(400).json({ error: 'Missing required fields: email, monday_item_id' });
  }

  try {
    // Send email
    await sendCalendlyEmail(lead_name, email);

    // Append note to Monday call summary
    const now = new Date();
    const dateStr = now.toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

    const note = `[${dateStr}] Lead asked to check calendar. Calendly booking link sent via email.`;
    await appendMondaySummary(monday_item_id, note);

    return res.status(200).json({ success: true });
  } catch (err) {
    console.error('send-link error:', err);
    return res.status(500).json({ error: err.message });
  }
};