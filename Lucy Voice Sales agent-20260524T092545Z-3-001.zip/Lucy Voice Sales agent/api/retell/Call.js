export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { monday_item_id } = req.body;

  if (!monday_item_id) {
    return res.status(400).json({ error: 'monday_item_id is required' });
  }

  const MONDAY_TOKEN = process.env.MONDAY_API_TOKEN;
  const RETELL_API_KEY = process.env.RETELL_API_KEY;
  const AGENT_ID = 'agent_82f187b32e8f5e7913da1c506f';

  try {
    // Fetch all required lead data from Monday in a single query
    const leadData = await getMondayLeadData(monday_item_id, MONDAY_TOKEN);

    const {
      name,
      phone,
      address,
      lead_profile,
      call_summary,
      last_phoned_answered,
      web_meeting_summary
    } = leadData;

    if (!phone) {
      return res.status(400).json({ error: 'No phone number found for this lead' });
    }

    // Format last call date for Lucy to use naturally in her opener
    const lastCallDate = formatDateForSpeech(last_phoned_answered);

    // Create the outbound call via Retell with all dynamic variables
    const retellResponse = await fetch('https://api.retellai.com/v2/create-phone-call', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${RETELL_API_KEY}`
      },
      body: JSON.stringify({
        agent_id: AGENT_ID,
        from_number: process.env.RETELL_FROM_NUMBER,
        to_number: `+${phone.replace(/\D/g, '')}`,
        retell_llm_dynamic_variables: {
          monday_item_id: monday_item_id.toString(),
          lead_name: name || '',
          address: address || '',
          lead_profile: lead_profile || '',
          call_summary: call_summary || '',          // Empty on call 1 — triggers standard opener
          last_call_date: lastCallDate || '',        // Empty on call 1 — not used in opener
          web_meeting_summary: web_meeting_summary || '' // Populated for Warm / Special offer leads
        }
      })
    });

    const retellData = await retellResponse.json();

    if (!retellResponse.ok) {
      console.error('Retell API error:', retellData);
      return res.status(500).json({ error: 'Failed to create call', details: retellData });
    }

    console.log(`Outbound call created for item ${monday_item_id}, call_id: ${retellData.call_id}`);
    return res.status(200).json({ success: true, call_id: retellData.call_id });

  } catch (error) {
    console.error('Call creation error:', error);
    return res.status(500).json({ error: error.message });
  }
}


// ─── Monday data fetch ────────────────────────────────────────────────────────

async function getMondayLeadData(itemId, token) {
  const query = `
    query {
      items(ids: [${itemId}]) {
        name
        column_values(ids: [
          "phone_mm1hp0a8",
          "text6",
          "text_mm1x8cgy",
          "long_text_mm239abs",
          "date_mm1vpqam"
        ]) {
          id
          text
        }
        updates(limit: 50) {
          text_body
        }
      }
    }
  `;

  const data = await mondayRequest(query, token);
  const item = data?.data?.items?.[0];

  if (!item) throw new Error(`No Monday item found for ID ${itemId}`);

  const colMap = {};
  for (const col of item.column_values) {
    colMap[col.id] = col.text || '';
  }

  // Find the most recent update whose body begins with "Web Meeting Summary"
  const updates = item.updates || [];
  const webMeetingUpdate = updates.find(u =>
    u.text_body && u.text_body.trim().toLowerCase().startsWith('web meeting summary')
  );

  return {
    name: item.name,
    phone: colMap['phone_mm1hp0a8'],
    address: colMap['text6'],
    lead_profile: colMap['text_mm1x8cgy'],
    call_summary: colMap['long_text_mm239abs'],
    last_phoned_answered: colMap['date_mm1vpqam'],
    web_meeting_summary: webMeetingUpdate ? webMeetingUpdate.text_body.trim() : ''
  };
}


// ─── Helpers ──────────────────────────────────────────────────────────────────

async function mondayRequest(query, token) {
  const response = await fetch('https://api.monday.com/v2', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': token
    },
    body: JSON.stringify({ query })
  });
  return response.json();
}

function formatDateForSpeech(dateString) {
  // Converts "2026-04-01" → "1st April" for natural use in Lucy's opener
  if (!dateString) return '';

  const date = new Date(dateString);
  if (isNaN(date.getTime())) return '';

  const day = date.getDate();
  const month = date.toLocaleDateString('en-GB', { month: 'long' });

  const suffix =
    day === 1 || day === 21 || day === 31 ? 'st' :
    day === 2 || day === 22 ? 'nd' :
    day === 3 || day === 23 ? 'rd' : 'th';

  return `${day}${suffix} ${month}`;
}
}