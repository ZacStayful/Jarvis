// api/presentation/sync.js
// Receives slide question responses from the Stayful pre-qualifier presentation.
// Called by sfSync() in the presentation JS on every answer — so responses
// land in Monday incrementally even if the lead abandons halfway through.
//
// POST body:
//   {
//     "item_id":   "11755194647",
//     "lead_name": "Olusina",
//     "address":   "6 Baobab Drive, Bilston, WV14 0RJ",
//     "responses": { "0": "Income consistency", "2": "Yes — more confident now" },
//     "formatted": "📋 Presentation responses — ...",
//     "timestamp": "2026-04-24T07:00:00.000Z"
//   }
//
// Monday columns written:
//   Presentation Responses (long_text_mm2pse8d) — full formatted response log
//   Slide Progress         (text_mm2pfnft)       — "X of 9 questions answered"

const BOARD_ID              = "5891626711";
const RESPONSES_COL         = "long_text_mm2pse8d";
const SLIDE_PROGRESS_COL    = "text_mm2pfnft";

module.exports = async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const { item_id, lead_name, address, responses, formatted, timestamp } = req.body || {};

  if (!item_id || !responses) {
    return res.status(400).json({ error: "Missing item_id or responses" });
  }

  const answeredCount = Object.keys(responses).length;
  const timeStr = new Date(timestamp || Date.now()).toLocaleString("en-GB", {
    timeZone: "Europe/London",
    day: "2-digit", month: "short",
    hour: "2-digit", minute: "2-digit",
  });

  const progressLabel = `${answeredCount} of 9 questions answered — ${timeStr}`;

  try {
    await fetch("https://api.monday.com/v2", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: process.env.MONDAY_API_KEY,
        "API-Version": "2024-01",
      },
      body: JSON.stringify({
        query: `mutation ($itemId: ID!, $boardId: ID!, $values: JSON!) {
          change_multiple_column_values(item_id: $itemId, board_id: $boardId, column_values: $values) { id }
        }`,
        variables: {
          itemId: String(item_id),
          boardId: BOARD_ID,
          values: JSON.stringify({
            [RESPONSES_COL]:      formatted || JSON.stringify(responses),
            [SLIDE_PROGRESS_COL]: progressLabel,
          }),
        },
      }),
    });

    console.log(`[presentation/sync] item ${item_id} (${lead_name}) — ${answeredCount} responses written`);
    return res.status(200).json({ ok: true, answers_written: answeredCount });
  } catch (err) {
    console.error("[presentation/sync] Error:", err.message);
    return res.status(500).json({ error: "Monday write failed" });
  }
};
